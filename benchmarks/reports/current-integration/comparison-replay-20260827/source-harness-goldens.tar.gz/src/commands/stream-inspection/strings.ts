import type { CommandDefinition } from "../../contracts/index.js";
import { integer, options, UsageError, value } from "../internal.js";
import { command, RecordBuffer, type StreamInspectionLimits } from "./shared.js";

export function createStringsCommand(limits: StreamInspectionLimits): CommandDefinition {
  return command("strings", limits, async session => {
    const parsed = options(session.context.args, "afn:t:", { all: "a", "print-file-name": "f", bytes: "n", radix: "t" });
    const minimum = integer(value(parsed, "n") ?? "4", 1);
    const radix = value(parsed, "t");
    if (radix !== undefined && !["d", "o", "x"].includes(radix)) throw new UsageError(`invalid radix '${radix}'`);
    await session.files(session.names(parsed.operands.filter(name => name !== "-")), async (source, name) => {
      const record = new RecordBuffer(session);
      let offset = 0, start = 0;
      const flush = async () => {
        if (record.size >= minimum) {
          const label = parsed.flags.has("f") ? `${name === "-" ? "{standard input}" : name}: ` : "";
          const location = radix === undefined ? "" : `${start.toString(radix === "x" ? 16 : radix === "o" ? 8 : 10).padStart(7, " ")} `;
          await session.output(new TextEncoder().encode(label + location));
          await session.output(record.view());
          await session.output(Uint8Array.of(10));
        }
        record.clear();
      };
      for await (const chunk of source) {
        for (const byte of chunk) {
          await session.step();
          if (byte === 9 || byte >= 32 && byte <= 126) {
            if (!record.size) start = offset;
            record.push(byte);
          } else await flush();
          offset++;
        }
      }
      await flush();
    });
  });
}
