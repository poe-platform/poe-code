import { FsError, type ByteSource, type CommandContext, type CommandDefinition } from "../contracts/index.js";
import { bufferLimit, concatenate, define, diagnostic, encoder, input, integer, lines, options, output, pathOf, requireOperands, UsageError, value } from "./internal.js";

function compareBytes(left: Uint8Array, right: Uint8Array): number { return Buffer.compare(left, right); }
function fold(bytes: Uint8Array): Uint8Array { return bytes.map(byte => byte >= 97 && byte <= 122 ? byte - 32 : byte); }

function numericCompare(left: Uint8Array, right: Uint8Array): number {
  const parse = (bytes: Uint8Array) => {
    const match = /^[ \t]*(-?)([0-9]*)(?:\.([0-9]*))?/u.exec(Buffer.from(bytes).toString("latin1"))!;
    const whole = (match[2] ?? "").replace(/^0+/u, "") || "0";
    const fraction = (match[3] ?? "").replace(/0+$/u, "");
    return { whole, fraction, negative: match[1] === "-" && (whole !== "0" || fraction !== "") };
  };
  const first = parse(left);
  const second = parse(right);
  if (first.negative !== second.negative) return first.negative ? -1 : 1;
  let compared = first.whole.length - second.whole.length;
  if (!compared) compared = first.whole < second.whole ? -1 : first.whole > second.whole ? 1 : 0;
  if (!compared) {
    const width = Math.max(first.fraction.length, second.fraction.length);
    const firstFraction = first.fraction.padEnd(width, "0");
    const secondFraction = second.fraction.padEnd(width, "0");
    compared = firstFraction < secondFraction ? -1 : firstFraction > secondFraction ? 1 : 0;
  }
  return first.negative ? -compared : compared;
}

interface SortKey { start: number; startCharacter: number; end?: number; endCharacter?: number; flags: Set<string> }

function sortKey(specification: string): SortKey {
  const match = /^([0-9]+)(?:\.([0-9]+))?([bfnr]*)(?:,([0-9]+)(?:\.([0-9]+))?([bfnr]*))?$/u.exec(specification);
  if (!match) throw new UsageError(`invalid key '${specification}'`);
  return {
    start: integer(match[1]!, 1), startCharacter: integer(match[2] ?? "1", 1),
    ...(match[4] === undefined ? {} : { end: integer(match[4], 1) }),
    ...(match[5] === undefined ? {} : { endCharacter: integer(match[5], 1) }),
    flags: new Set((match[3] ?? "") + (match[6] ?? "")),
  };
}

function keyBytes(line: Uint8Array, key: SortKey, separator: number | undefined, blanks: boolean): Uint8Array {
  const fields: { start: number; end: number }[] = [];
  if (separator !== undefined) {
    let start = 0;
    for (let offset = 0; offset <= line.length; offset++) if (offset === line.length || line[offset] === separator) {
      fields.push({ start, end: offset }); start = offset + 1;
    }
  } else {
    let offset = 0;
    while (offset < line.length) {
      const leading = offset;
      while (offset < line.length && (line[offset] === 32 || line[offset] === 9)) offset++;
      const start = blanks ? offset : leading;
      if (offset === line.length) break;
      while (offset < line.length && line[offset] !== 32 && line[offset] !== 9) offset++;
      fields.push({ start, end: offset });
    }
  }
  const start = (fields[key.start - 1]?.start ?? line.length) + key.startCharacter - 1;
  const last = key.end === undefined ? undefined : fields[key.end - 1];
  const end = key.end === undefined ? line.length : last === undefined ? line.length
    : key.endCharacter === undefined ? last.end : Math.min(last.end, last.start + key.endCharacter);
  return line.subarray(Math.min(start, line.length), Math.max(start, end));
}

async function emitRecords(context: CommandContext, records: ByteSource, destination?: string): Promise<void> {
  if (destination === undefined) { for await (const bytes of records) await output(context, bytes); return; }
  if (context.fs.writeStream) await context.fs.writeStream(pathOf(context, destination), records, { signal: context.signal });
  else {
    let size = 0;
    const chunks: Uint8Array[] = [];
    for await (const bytes of records) {
      size += bytes.length;
      if (size > bufferLimit) throw new FsError("EFBIG", { message: "output buffer limit exceeded" });
      chunks.push(bytes);
    }
    await context.fs.writeFile(pathOf(context, destination), concatenate(chunks, size), { signal: context.signal });
  }
}

export function textCommands(): CommandDefinition[] {
  return [
    define("sort", async context => {
      const parsed = options(context.args, "nrfbuszt:k:o:c", { "numeric-sort": "n", reverse: "r", "ignore-case": "f", "ignore-leading-blanks": "b", unique: "u", stable: "s", "zero-terminated": "z", "field-separator": "t", key: "k", output: "o", check: "c" });
      const separatorText = value(parsed, "t");
      if (separatorText !== undefined && encoder.encode(separatorText).length !== 1) throw new UsageError("field separator must be one byte");
      const separator = separatorText === undefined ? undefined : encoder.encode(separatorText)[0];
      const keys = (parsed.values.get("k") ?? []).map(sortKey);
      const keyCompare = (left: Uint8Array, right: Uint8Array) => {
        for (const key of keys.length ? keys : [undefined]) {
          const flags = key?.flags.size ? key.flags : parsed.flags;
          let first = key ? keyBytes(left, key, separator, flags.has("b")) : left;
          let second = key ? keyBytes(right, key, separator, flags.has("b")) : right;
          if (!key && flags.has("b")) {
            const trim = (bytes: Uint8Array) => { let offset = 0; while (bytes[offset] === 9 || bytes[offset] === 32) offset++; return bytes.subarray(offset); };
            first = trim(first); second = trim(second);
          }
          if (flags.has("f")) { first = fold(first); second = fold(second); }
          let result = flags.has("n") ? numericCompare(first, second) : compareBytes(first, second);
          if (flags.has("r")) result = -result;
          if (result) return result;
        }
        return 0;
      };
      const compare = (left: Uint8Array, right: Uint8Array) => keyCompare(left, right)
        || (parsed.flags.has("s") || parsed.flags.has("u") ? 0 : compareBytes(left, right) * (parsed.flags.has("r") ? -1 : 1));
      const records: Uint8Array[] = [];
      let size = 0;
      let exitCode = 0;
      const delimiter = parsed.flags.has("z") ? 0 : 10;
      for (const name of parsed.operands.length ? parsed.operands : ["-"]) {
        try {
          for await (const line of lines(input(context, name), delimiter)) {
            context.signal.throwIfAborted();
            size += line.bytes.length + 1;
            if (size > bufferLimit) throw new FsError("EFBIG", { message: "sort buffer limit exceeded" });
            if (parsed.flags.has("c") && records.length && (compare(records.at(-1)!, line.bytes) > 0 || parsed.flags.has("u") && keyCompare(records.at(-1)!, line.bytes) === 0)) {
              await diagnostic(context, new Error(`disorder at record ${records.length + 1}`));
              return { exitCode: 1 };
            }
            records.push(line.bytes);
          }
        } catch (error) { await diagnostic(context, error); exitCode = 1; }
      }
      if (parsed.flags.has("c")) return { exitCode };
      records.sort(compare);
      const sorted = (async function* (): ByteSource {
        let previous: Uint8Array | undefined;
        for (const record of records) {
          if (parsed.flags.has("u") && previous !== undefined && keyCompare(previous, record) === 0) continue;
          yield concatenate([record, Uint8Array.of(delimiter)]);
          previous = record;
        }
      })();
      await emitRecords(context, sorted, value(parsed, "o"));
      return { exitCode };
    }),
    define("uniq", async context => {
      const parsed = options(context.args, "cduif:s:w:z", { count: "c", repeated: "d", unique: "u", "ignore-case": "i", "skip-fields": "f", "skip-chars": "s", "check-chars": "w", "zero-terminated": "z" });
      requireOperands(parsed.operands, 0, 2);
      const skipFields = integer(value(parsed, "f") ?? "0");
      const skipCharacters = integer(value(parsed, "s") ?? "0");
      const width = value(parsed, "w") === undefined ? Infinity : integer(value(parsed, "w")!);
      const delimiter = parsed.flags.has("z") ? 0 : 10;
      const key = (bytes: Uint8Array) => {
        let offset = 0;
        for (let field = 0; field < skipFields; field++) {
          while (offset < bytes.length && (bytes[offset] === 32 || bytes[offset] === 9)) offset++;
          while (offset < bytes.length && bytes[offset] !== 32 && bytes[offset] !== 9) offset++;
        }
        offset += skipCharacters;
        const result = bytes.subarray(offset, width === Infinity ? undefined : offset + width);
        return parsed.flags.has("i") ? fold(result) : result;
      };
      const records = (async function* (): ByteSource {
        let previous: Uint8Array | undefined;
        let previousKey: Uint8Array | undefined;
        let count = 0;
        const selected = () => (!parsed.flags.has("d") || count > 1) && (!parsed.flags.has("u") || count === 1);
        const record = () => concatenate([...(parsed.flags.has("c") ? [encoder.encode(`${String(count).padStart(7)} `)] : []), previous!, Uint8Array.of(delimiter)]);
        for await (const line of lines(input(context, parsed.operands[0]), delimiter)) {
          context.signal.throwIfAborted();
          const currentKey = key(line.bytes);
          if (previousKey && compareBytes(previousKey, currentKey) === 0) count++;
          else {
            if (previous !== undefined && selected()) yield record();
            previous = line.bytes; previousKey = currentKey; count = 1;
          }
        }
        if (previous !== undefined && selected()) yield record();
      })();
      if (parsed.operands[1] !== undefined && parsed.operands[0] !== "-"
        && pathOf(context, parsed.operands[0]!) === pathOf(context, parsed.operands[1])) throw new UsageError("input and output must be different files");
      await emitRecords(context, records, parsed.operands[1]);
      return { exitCode: 0 };
    }),
    define("cut", async context => {
      const parsed = options(context.args, "b:c:f:d:szo:C", { bytes: "b", characters: "c", fields: "f", delimiter: "d", "only-delimited": "s", "zero-terminated": "z", "output-delimiter": "o", complement: "C" });
      const modes = ["b", "c", "f"].filter(mode => parsed.flags.has(mode));
      if (modes.length !== 1) throw new UsageError("exactly one byte, character, or field list is required");
      const mode = modes[0]!;
      if (mode !== "f" && (parsed.flags.has("d") || parsed.flags.has("s"))) throw new UsageError("delimiter options require field mode");
      const ranges = value(parsed, mode)!.split(/[ ,]+/u).map(part => {
        const match = /^(?:([0-9]+)(?:-([0-9]*))?|-([0-9]+))$/u.exec(part);
        if (!match) throw new UsageError(`invalid range '${part}'`);
        const start = match[3] === undefined ? integer(match[1]!, 1) : 1;
        const end = match[3] !== undefined ? integer(match[3], 1) : match[2] === undefined ? start : match[2] === "" ? Infinity : integer(match[2], 1);
        if (end < start) throw new UsageError(`decreasing range '${part}'`);
        return { start, end };
      });
      const selected = (position: number) => ranges.some(range => position >= range.start && position <= range.end) !== parsed.flags.has("C");
      const delimiter = value(parsed, "d") ?? "\t";
      if ([...delimiter].length !== 1) throw new UsageError("delimiter must be a single character");
      const outputDelimiter = value(parsed, "o");
      const recordDelimiter = parsed.flags.has("z") ? 0 : 10;
      let exitCode = 0;
      for (const name of parsed.operands.length ? parsed.operands : ["-"]) {
        try {
          for await (const line of lines(input(context, name), recordDelimiter)) {
            context.signal.throwIfAborted();
            let bytes: Uint8Array;
            if (mode === "f") {
              const record = Buffer.from(line.bytes.buffer, line.bytes.byteOffset, line.bytes.byteLength);
              const separator = encoder.encode(delimiter);
              let boundary = record.indexOf(separator);
              if (boundary < 0) {
                if (parsed.flags.has("s")) continue;
                bytes = line.bytes;
              } else {
                const pieces: Uint8Array[] = [];
                const joiner = encoder.encode(outputDelimiter ?? delimiter);
                let field = 1;
                let start = 0;
                let emitted = false;
                while (true) {
                  if (selected(field++)) {
                    if (emitted) pieces.push(joiner);
                    pieces.push(record.subarray(start, boundary < 0 ? record.length : boundary));
                    emitted = true;
                  }
                  if (boundary < 0) break;
                  start = boundary + separator.length;
                  boundary = record.indexOf(separator, start);
                }
                bytes = concatenate(pieces);
              }
            } else if (mode === "b") {
              const chunks: Uint8Array[] = [];
              let start = -1;
              let emitted = false;
              for (let index = 0; index <= line.bytes.length; index++) {
                const included = index < line.bytes.length && selected(index + 1);
                if (included && start < 0) start = index;
                if (!included && start >= 0) {
                  if (emitted && outputDelimiter !== undefined) chunks.push(encoder.encode(outputDelimiter));
                  chunks.push(line.bytes.subarray(start, index)); emitted = true; start = -1;
                }
              }
              bytes = concatenate(chunks);
            } else {
              const text = new TextDecoder().decode(line.bytes);
              const pieces: string[] = [];
              let index = 0;
              let offset = 0;
              let start = -1;
              for (const character of text) {
                const included = selected(++index);
                if (included && start < 0) start = offset;
                if (!included && start >= 0) { pieces.push(text.slice(start, offset)); start = -1; }
                offset += character.length;
              }
              if (start >= 0) pieces.push(text.slice(start));
              bytes = encoder.encode(pieces.join(outputDelimiter ?? ""));
            }
            await output(context, bytes);
            await output(context, Uint8Array.of(recordDelimiter));
          }
        } catch (error) { await diagnostic(context, error); exitCode = 1; }
      }
      return { exitCode };
    }),
  ];
}
