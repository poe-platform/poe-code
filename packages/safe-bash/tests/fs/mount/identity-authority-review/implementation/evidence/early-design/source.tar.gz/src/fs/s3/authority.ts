import type { EntryComparison, FileSystem, FsOptions } from "../../contracts/filesystem.js";
import type { EntryView } from "../mount/comparison.js";
import type { S3Client } from "./transport.js";

export interface OwnedS3Entry {
  readonly storage: object;
  readonly key: string;
}

interface ProviderOwner {
  readonly unchanged: () => boolean;
  readonly bucket?: (name: string) => object | undefined;
  readonly forwarded?: S3Client;
}

const providers = new WeakMap<S3Client, ProviderOwner>();
const entries = new WeakMap<FileSystem, (view: EntryView) => OwnedS3Entry | undefined>();
const operations = ["headObject", "getObject", "putObject", "deleteObject", "copyObject", "listObjectsV2", "getObjectStream", "putObjectStream"] as const;

function unchangedClient(client: S3Client): () => boolean {
  const methods = operations.map(name => client[name]);
  return () => operations.every((name, index) => client[name] === methods[index]);
}

export function registerMockS3Owner(client: S3Client, bucket: (name: string) => object | undefined): void {
  providers.set(client, { unchanged: unchangedClient(client), bucket });
}

export function forwardS3Owner(client: S3Client, transport: S3Client): void {
  providers.set(transport, { unchanged: unchangedClient(transport), forwarded: client });
}

export function ownedS3Bucket(client: S3Client, name: string): object | undefined {
  const visited = new Set<S3Client>();
  let current: S3Client | undefined = client;
  while (current !== undefined && !visited.has(current)) {
    visited.add(current);
    const owner: ProviderOwner | undefined = providers.get(current);
    if (!owner?.unchanged()) return undefined;
    if (owner.bucket) return owner.bucket(name);
    current = owner.forwarded;
  }
  return undefined;
}

export function registerS3EntryOwner(filesystem: FileSystem, describe: (view: EntryView) => OwnedS3Entry | undefined): void {
  const names = ["stat", "lstat", "realpath", "readFile", "writeFile", "copyFile", "rename", "readStream", "writeStream"] as const;
  const methods = names.map(name => filesystem[name]);
  entries.set(filesystem, view => names.every((name, index) => filesystem[name] === methods[index]) ? describe(view) : undefined);
}

export function getOwnedS3Entry(view: EntryView): OwnedS3Entry | undefined {
  return entries.get(view.filesystem)?.(view);
}

export async function compareOwnedS3Entries(own: EntryView, peer: EntryView, options: FsOptions): Promise<EntryComparison> {
  options.signal?.throwIfAborted();
  const left = getOwnedS3Entry(own);
  options.signal?.throwIfAborted();
  const right = getOwnedS3Entry(peer);
  options.signal?.throwIfAborted();
  if (!left || !right) return "unknown";
  return left.storage === right.storage && left.key === right.key ? "same" : "distinct";
}
