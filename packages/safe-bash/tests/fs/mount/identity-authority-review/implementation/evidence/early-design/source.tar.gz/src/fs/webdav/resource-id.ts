import type { EntryComparison, FileSystem, FsOptions } from "../../contracts/filesystem.js";
import type { EntryAuthority } from "../mount/comparison.js";

type ResourceQuery = (path: string, options: FsOptions) => Promise<string | undefined>;
const queries = new WeakMap<FileSystem, ResourceQuery>();

export function registerResourceQuery(filesystem: FileSystem, query: ResourceQuery): void {
  queries.set(filesystem, query);
}

export function resourceIdentifier(value: string): string {
  if (!/^[A-Za-z][A-Za-z0-9+.-]*:[^\s<>"{}|\\^`]+$/.test(value) || /%(?![0-9A-Fa-f]{2})/.test(value)
    || /[^\x21-\x7e]/.test(value)) throw new Error("invalid DAV:resource-id URI");
  new URL(value);
  if (/^urn:uuid:/i.test(value)) {
    if (!/^urn:uuid:[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value)) {
      throw new Error("invalid DAV:resource-id UUID");
    }
    return value.toLowerCase();
  }
  return value;
}

export const compareWebDavResources: EntryAuthority = async (own, peer, options): Promise<EntryComparison> => {
  const ownQuery = queries.get(own.filesystem);
  const peerQuery = queries.get(peer.filesystem);
  if (!ownQuery || !peerQuery) return "unknown";
  options.signal?.throwIfAborted();
  const ownId = await ownQuery(own.path, options);
  options.signal?.throwIfAborted();
  const peerId = await peerQuery(peer.path, options);
  options.signal?.throwIfAborted();
  if (ownId === undefined || peerId === undefined) return "unknown";
  return ownId === peerId ? "same" : "distinct";
};
