import assert from 'node:assert/strict'; import {readFileSync} from 'node:fs'; import {Shell,MemoryFileSystem,agentCommands} from 'virtual-bash';
const boundary=JSON.parse(readFileSync('package.json')); assert.notEqual(boundary.name,'virtual-bash');
const resolved=import.meta.resolve('virtual-bash'); assert.equal(resolved,"file:///Users/kjopek/Workspace/safe-bash/tests/integration/adapter-tools/atomic-webdav-profile-independent/.isolated-XCrUhe/consumer/node_modules/virtual-bash/dist/index.js");
const shell=new Shell({fs:new MemoryFileSystem()}).use(agentCommands());
try { assert.equal((await shell.exec(':')).exitCode,0); const names=["cat","cp","find","mkdir","mv","printf","pwd","rm","rmdir","sort","tee","test","touch","xargs","sed","awk","jq","rg","sha256sum","gzip","diff","patch"];
for(const name of names) assert.equal(typeof shell.commands.get(name)?.execute,'function',name);
assert.equal(shell.commands.get('curl'),undefined); assert.equal(shell.commands.get('safejs'),undefined);
console.log(JSON.stringify({boundary:boundary.name,resolved,aggregate:true,requiredNames:names})); } finally {await shell.dispose();}