import { FsError, resolvePath, type CommandDefinition, type FileStat } from "../../contracts/index.js";
import { compareObservedEntries } from "../copy-identity.js";
import { parse, help, type Arguments } from "./arguments.js";
import { escaped, message, TreeLimitError, UsageError, WalkBudget } from "./io.js";
import { settings, type TreeCommandsOptions } from "./options.js";
import { matches } from "./pattern.js";

interface Entry {
  readonly path: string;
  readonly display: string;
  readonly name: string;
  stat?: FileStat;
  followed?: FileStat;
  target?: string;
  error?: string;
  cycle?: boolean;
}

function directory(entry: Entry): boolean { return (entry.followed ?? entry.stat)?.type === "directory"; }

function serialized(value: unknown): string {
  return JSON.stringify(value).replace(/[\u007f-\u009f\u2028\u2029\p{Cf}]/gu,
    character => character.split("").map(unit => `\\u${unit.charCodeAt(0).toString(16).padStart(4, "0")}`).join(""));
}

class Walker {
  private directories = 0;
  private files = 0;
  private failed = false;
  constructor(private readonly budget: WalkBudget, private readonly args: Arguments) {}

  async inspect(path: string, display: string, name: string): Promise<Entry> {
    const { context } = this.budget;
    const options = { signal: context.signal };
    const entry: Entry = { path, display, name };
    this.budget.text(path);
    this.budget.text(display);
    try {
      entry.stat = await this.budget.fs(() => context.fs.lstat(path, options));
      if (entry.stat.type === "symlink") {
        if (!context.fs.readlink) throw new FsError("ENOTSUP", { path, syscall: "readlink" });
        entry.target = await this.budget.fs(() => context.fs.readlink!(path, options));
        try { entry.followed = await this.budget.fs(() => context.fs.stat(path, options)); }
        catch (error) {
          context.signal.throwIfAborted();
          if (!(error instanceof FsError) || (error.code !== "ENOENT" && error.code !== "ENOTDIR")) throw error;
        }
      }
    } catch (error) {
      context.signal.throwIfAborted();
      if (error instanceof TreeLimitError) throw error;
      entry.error = message(error);
    }
    if (entry.target !== undefined) this.budget.text(entry.target);
    return entry;
  }

  async children(entry: Entry, ancestors: readonly Entry[], depth: number): Promise<Entry[]> {
    const { context, limits } = this.budget;
    if (entry.error || !directory(entry) || (entry.stat?.type === "symlink" && !this.args.follow)) return [];
    if (depth === this.args.level) return [];
    this.budget.check(depth + 1, limits.maxDepth, "depth");
    let listing;
    try {
      for (const ancestor of ancestors) {
        const same = await this.budget.fs(() => compareObservedEntries(context.fs, entry.path, (entry.followed ?? entry.stat)!,
          context.fs, ancestor.path, (ancestor.followed ?? ancestor.stat)!, { signal: context.signal }));
        if (same === "same") { entry.cycle = true; return []; }
      }
      listing = await this.budget.fs(() => context.fs.readdir(entry.path, { signal: context.signal }));
    } catch (error) {
      context.signal.throwIfAborted();
      if (error instanceof TreeLimitError) throw error;
      entry.error = message(error); return [];
    }
    this.budget.check(listing.length, limits.maxDirectoryEntries, "directory entry");
    this.budget.entry(listing.length);
    const names = new Set<string>();
    const candidates: { name: string; bytes: Uint8Array }[] = [];
    for (const item of listing) {
      this.budget.step();
      this.budget.text(item.name);
      if (item.name === "." || item.name === "..") continue;
      if (!item.name || item.name.includes("/") || item.name.includes("\0") || /[\ud800-\udfff]/u.test(item.name) || names.has(item.name)) {
        entry.error = "invalid or duplicate directory entry"; return [];
      }
      names.add(item.name);
      if (!this.args.all && item.name.startsWith(".")) continue;
      const bytes = new TextEncoder().encode(item.name);
      if (this.args.exclude.some(pattern => matches(pattern, bytes, this.budget))) continue;
      candidates.push({ name: item.name, bytes });
    }
    candidates.sort((left, right) => {
      this.budget.step();
      return Buffer.compare(left.bytes, right.bytes) * (this.args.reverse ? -1 : 1);
    });
    const children: Entry[] = [];
    for (const item of candidates) {
      const child = await this.inspect(resolvePath(entry.path, item.name), `${entry.display.replace(/\/$/u, "")}/${item.name}`, item.name);
      if (!child.error) {
        if (this.args.directories && !directory(child)) continue;
        const includeDirectory = child.stat?.type === "directory" || (this.args.follow && directory(child));
        if (!includeDirectory && this.args.include.length && !this.args.include.some(pattern => matches(pattern, item.bytes, this.budget))) continue;
      }
      children.push(child);
    }
    if (this.args.dirsFirst) children.sort((left, right) => Number(directory(right)) - Number(directory(left)));
    return children;
  }

  async visit(entry: Entry, ancestors: readonly Entry[], prefix: string, last: boolean, depth: number): Promise<void> {
    const children = await this.children(entry, ancestors, depth);
    if (directory(entry)) { if (depth > 0 || children.length) this.directories++; }
    else if (entry.stat) this.files++;
    if (entry.error) {
      this.budget.text(entry.error);
      this.failed = true;
      await this.budget.emit(this.budget.context.stderr, `tree: ${escaped(entry.display)}: ${escaped(entry.error)}\n`);
    }
    const name = depth === 0 || this.args.full ? entry.display : entry.name;
    const annotation = entry.error ?? (entry.cycle ? "recursive, not followed" : undefined);
    if (this.args.json) {
      const fields = { type: entry.stat?.type === "symlink" ? "link" : entry.stat?.type ?? "unknown", name,
        ...(entry.target === undefined ? {} : { target: entry.target }), ...(annotation === undefined ? {} : { error: annotation }) };
      await this.write(`${this.padding(depth + 1)}${serialized(fields).slice(0, -1)}`);
      if (children.length) {
        await this.write(`,"contents":[${this.newline()}`);
        for (let index = 0; index < children.length; index++) {
          if (index) await this.write(`,${this.newline()}`);
          await this.visit(children[index]!, [...ancestors, entry], "", index === children.length - 1, depth + 1);
        }
        await this.write(`${this.newline()}${this.padding(depth + 1)}]`);
      }
      await this.write("}");
    } else {
      const utf8 = this.args.charset === "UTF-8";
      const branch = this.args.indent && depth > 0 ? prefix + (last ? (utf8 ? "└── " : "`-- ") : (utf8 ? "├── " : "|-- ")) : "";
      await this.write(`${branch}${escaped(name)}${entry.target === undefined ? "" : ` -> ${escaped(entry.target)}`}${annotation === undefined ? "" : `  [${escaped(annotation)}]`}\n`);
      const childPrefix = depth === 0 ? "" : prefix + (last ? "    " : utf8 ? "│   " : "|   ");
      for (let index = 0; index < children.length; index++) {
        await this.visit(children[index]!, [...ancestors, entry], childPrefix, index === children.length - 1, depth + 1);
      }
    }
  }

  private newline(): string { return this.args.indent ? "\n" : ""; }
  private padding(depth: number): string { return this.args.indent ? "  ".repeat(depth) : ""; }
  private write(value: string): Promise<void> { return this.budget.emit(this.budget.context.stdout, value); }

  async run(): Promise<number> {
    if (this.args.json) await this.write(`[${this.newline()}`);
    for (let index = 0; index < this.args.operands.length; index++) {
      const operand = this.args.operands[index]!;
      this.budget.entry();
      if (this.args.json && index) await this.write(`,${this.newline()}`);
      const entry = await this.inspect(resolvePath(this.budget.context.cwd, operand), operand, operand);
      await this.visit(entry, [], "", true, 0);
    }
    if (this.args.report) {
      if (this.args.json) {
        await this.write(`,${this.newline()}${this.padding(1)}${serialized({ type: "report", directories: this.directories,
          ...(this.args.directories ? {} : { files: this.files }) })}`);
      } else await this.write(`\n${this.directories} ${this.directories === 1 ? "directory" : "directories"}${this.args.directories ? "" : `, ${this.files} ${this.files === 1 ? "file" : "files"}`}\n`);
    }
    if (this.args.json) await this.write(`${this.newline()}]\n`);
    return this.failed ? 1 : 0;
  }
}

export function createTreeCommand(options: TreeCommandsOptions = {}): CommandDefinition {
  const limits = settings(options);
  return { name: "tree", description: "List a bounded virtual directory tree", async execute(context) {
    const budget = new WalkBudget(context, limits);
    let args: Arguments;
    try { args = parse(context.args, budget); }
    catch (error) {
      context.signal.throwIfAborted();
      if (!(error instanceof UsageError)) throw error;
      await budget.emit(context.stderr, `tree: ${escaped(error.message)}\n`);
      return { exitCode: 2 };
    }
    if (args.help || args.version) {
      await budget.emit(context.stdout, args.help ? help : "tree (virtual-bash bounded profile) 1\n");
      return { exitCode: 0 };
    }
    return { exitCode: await new Walker(budget, args).run() };
  } };
}
