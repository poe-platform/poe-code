import type { EntryComparison, FileStat, FileSystem, FsOptions } from "../../contracts/filesystem.js";
import type { EntryAuthority, EntryView } from "../mount/comparison.js";
import { FsError } from "../../contracts/errors.js";

export interface OwnedWebDavEntry {
  readonly storage: object;
  readonly resource: object;
}

export interface OwnedWebDavResource extends OwnedWebDavEntry {
  readonly identifier: string;
}

const responses = new WeakMap<Response, ReadonlyMap<string, OwnedWebDavResource>>();
const observations = new WeakMap<FileStat, { filesystem: FileSystem; path: string; entry: OwnedWebDavResource }>();
const unchanged = new WeakMap<FileSystem, () => boolean>();

export function registerOwnedResourceResponse(response: Response, entries: ReadonlyMap<string, OwnedWebDavResource>): void {
  if (responses.has(response)) throw new TypeError("resource response already registered");
  responses.set(response, new Map(entries));
}

export function recordOwnedResourceStat(response: Response, filesystem: FileSystem, path: string, stat: FileStat): void {
  const entry = responses.get(response)?.get(path);
  if (entry) observations.set(stat, { filesystem, path, entry });
}

export function getOwnedWebDavEntry(view: EntryView): OwnedWebDavEntry | undefined {
  const observation = observations.get(view.stat);
  return observation?.filesystem === view.filesystem && observation.path === view.path && unchanged.get(view.filesystem)?.()
    ? observation.entry : undefined;
}

export function ownedResponseIdentifier(response: Response, path: string): string | undefined {
  return responses.get(response)?.get(path)?.identifier;
}

type ResourceQuery = (path: string, options: FsOptions) => Promise<string | undefined>;
const queries = new WeakMap<FileSystem, ResourceQuery>();

export function registerResourceQuery(filesystem: FileSystem, query: ResourceQuery): void {
  const names = ["stat", "lstat", "realpath", "readFile", "writeFile", "copyFile", "rename", "readStream", "writeStream"] as const;
  const methods = names.map(name => filesystem[name]);
  const valid = () => names.every((name, index) => filesystem[name] === methods[index]);
  unchanged.set(filesystem, valid);
  queries.set(filesystem, (path, options) => valid() ? query(path, options) : Promise.resolve(undefined));
}

export function resourceIdentifier(value: string): string {
  if (!/^[A-Za-z][A-Za-z0-9+.-]*:[^\s<>"{}|\\^`]+$/.test(value) || /%(?![0-9A-Fa-f]{2})/.test(value)
    || /[^\x21-\x7e]/.test(value)) throw new Error("invalid DAV:resource-id URI");
  new URL(value);
  if (/^urn:uuid:/i.test(value)) {
    if (!/^urn:uuid:[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value)) {
      throw new Error("invalid DAV:resource-id UUID");
    }
    return value.toLowerCase();
  }
  return value;
}

export const compareWebDavResources: EntryAuthority = async (own, peer, options): Promise<EntryComparison> => {
  options.signal?.throwIfAborted();
  const left = getOwnedWebDavEntry(own);
  const right = getOwnedWebDavEntry(peer);
  const ownQuery = queries.get(own.filesystem);
  const peerQuery = queries.get(peer.filesystem);
  if (!ownQuery || !peerQuery) return "unknown";
  options.signal?.throwIfAborted();
  const ownId = await ownQuery(own.path, options);
  options.signal?.throwIfAborted();
  const peerId = await peerQuery(peer.path, options);
  options.signal?.throwIfAborted();
  if (ownId === undefined || peerId === undefined) return "unknown";
  if (left && right) {
    const same = left.storage === right.storage && left.resource === right.resource;
    if (same !== (ownId === peerId)) throw new FsError("EIO", { path: own.path, dest: peer.path, message: "conflicting owned and protocol WebDAV identities" });
  }
  return ownId === peerId ? "same" : "distinct";
};
